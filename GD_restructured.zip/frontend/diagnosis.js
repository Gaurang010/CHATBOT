import React, { useState } from "react";
import axios from "axios";

const DiagnosisForm = () => {
    const [symptoms, setSymptoms] = useState("");
    const [prediction, setPrediction] = useState(null);

    const handlePredict = async () => {
        try {
            const response = await axios.post("http://127.0.0.1:5000/predict", {
                symptoms: symptoms.split(","),
            });
            setPrediction(response.data.disease);
        } catch (error) {
            console.error("Error:", error);
        }
    };

    return (
        <div>
            <h2>Disease Prediction</h2>
            <input
                type="text"
                placeholder="Enter symptoms, comma-separated"
                value={symptoms}
                onChange={(e) => setSymptoms(e.target.value)}
            />
            <button onClick={handlePredict}>Predict</button>
            {prediction && <h3>Predicted Disease: {prediction}</h3>}
        </div>
    );
};

export default DiagnosisForm;
