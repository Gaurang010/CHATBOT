import pandas as pd
import numpy as np
import joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from xgboost import XGBClassifier

# 1️⃣ Sample Dataset (You can replace this with real medical data)
data = {
    "Age": np.random.randint(20, 80, 100),
    "Fever": np.random.choice([0, 1], 100),
    "Cough": np.random.choice([0, 1], 100),
    "Fatigue": np.random.choice([0, 1], 100),
    "Disease": np.random.choice(["Flu", "Cold", "COVID-19"], 100)
}

df = pd.DataFrame(data)

# 2️⃣ Encode the target labels (diseases)
label_encoder = LabelEncoder()
df["Disease"] = label_encoder.fit_transform(df["Disease"])

# 3️⃣ Split into training & test sets
X = df.drop(columns=["Disease"])
y = df["Disease"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 4️⃣ Train the XGBoost Model
model = XGBClassifier(use_label_encoder=False, eval_metric="logloss")
model.fit(X_train, y_train)

# 5️⃣ Create a `models` folder and save the model
import os
os.makedirs("backend/models", exist_ok=True)

joblib.dump(model, "backend/models/xgboost_disease_model.pkl")
joblib.dump(label_encoder, "backend/models/label_encoder.pkl")
joblib.dump({i: label for i, label in enumerate(label_encoder.classes_)}, "backend/models/disease_mapping.pkl")

print("✅ Model training complete! Files saved in `backend/models/`")
