from flask import Flask, request, jsonify
import joblib
import pandas as pd
import numpy as np
import os

app = Flask(__name__)

# ✅ Load the trained ML model and encoders
model_path = "backend/models/xgboost_disease_model.pkl"
encoder_path = "backend/models/label_encoder.pkl"
mapping_path = "backend/models/disease_mapping.pkl"

if not os.path.exists(model_path):
    raise FileNotFoundError("❌ Model file missing! Run `train_model.py` first.")

model = joblib.load(model_path)
label_encoder = joblib.load(encoder_path)
disease_mapping = joblib.load(mapping_path)
model_features = model.feature_names_in_

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    user_input = data.get("input", "").lower().strip()

    # ✅ Map input to model features
    user_data = {
        "Age": int(user_input) if user_input.isdigit() else 30,
        "Fever": 1 if "yes" in user_input else 0,
        "Cough": 1 if "cough" in user_input else 0,
        "Fatigue": 1 if "fatigue" in user_input else 0
    }

    # ✅ Convert input to DataFrame
    user_df = pd.DataFrame([user_data])
    for col in model_features:
        if col not in user_df:
            user_df[col] = 0  
    user_df = user_df[model_features]

    # ✅ Make a prediction
    predicted_probs = model.predict_proba(user_df)[0]
    max_index = np.argmax(predicted_probs)
    predicted_disease = disease_mapping.get(max_index, "Unknown Disease")
    confidence = predicted_probs[max_index] * 100

    return jsonify({"reply": f"🩺 You may have **{predicted_disease}** (Confidence: {confidence:.2f}%)"})

if __name__ == "__main__":
    app.run(debug=True, port=5000)
